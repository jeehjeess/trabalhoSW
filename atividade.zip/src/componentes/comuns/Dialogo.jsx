function Dialogo({ texto }) {
    return (
        <div className="valid-feedback">
           <p>  Campo descrição OK</p>
        </div>

    )
};

export default Dialogo;