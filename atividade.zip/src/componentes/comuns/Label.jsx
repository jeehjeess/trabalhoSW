function Label ({texto}){
    return (
        <p>{texto}</p>
    )
};

export default Label;